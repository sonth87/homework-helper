/**
 * Multi-Provider AI Streaming Client
 * Connects directly to Google Gemini, OpenAI, Claude, DeepSeek, Groq, and Custom endpoints.
 * Handles multimodal vision (images) and text streaming with automatic failover.
 */

import { keyRotator } from './key-rotator.js';
import { Storage, DEFAULT_NANO_SYSTEM_PROMPT } from '../shared/storage.js';
import { formatStudyPrompt } from '../shared/study-prompt.js';
import { streamViaOffscreen } from './offscreen-ai-bridge.js';

export class AiEngine {
  /**
   * Main entrypoint to ask AI with text and optional image
   * @param {Object} params
   * @param {string} params.prompt - Text question / instructions
   * @param {string} [params.imageBase64] - Optional base64 image (with or without data URL prefix)
   * @param {string} [params.studyMode] - 'step-by-step' | 'direct' | 'hint' | 'explain' | 'translate'
   * @param {string} [params.preferredConfigId] - Specific config ID or null for auto-rotation
   * @param {Function} onChunk - Callback for incremental text chunks: onChunk(text, metadata)
   * @param {AbortSignal} [signal] - Abort signal
   */
  static async ask({ prompt, imageBase64, studyMode, preferredConfigId, systemPrompt, outputLanguage = 'en' }, onChunk, signal) {
    const { routingStrategy = 'prefer_nano', apiConfigs = [], nanoSystemPrompt } = await Storage.get(['routingStrategy', 'apiConfigs', 'nanoSystemPrompt']);
    const enabledKeys = (apiConfigs || []).filter((c) => c.isEnabled && c.apiKey);

    const langNames = {
      en: 'English',
      vi: 'Tiếng Việt (Vietnamese)',
      es: 'Español (Spanish)',
      fr: 'Français (French)',
      de: 'Deutsch (German)',
      'zh-CN': 'Simplified Chinese (简体中文)',
      'zh-TW': 'Traditional Chinese (繁體中文)',
      ja: 'Japanese (日本語)',
      ko: 'Korean (한국어)',
      pt: 'Portuguese (Português)',
      id: 'Bahasa Indonesia',
      ru: 'Russian (Русский)',
    };
    const targetLangName = (outputLanguage && outputLanguage !== 'auto') ? (langNames[outputLanguage] || outputLanguage) : 'Tiếng Việt (Vietnamese)';
    let directSysInstruction = '';
    if (studyMode === 'direct') {
      directSysInstruction = `\n\n[STRICT DIRECT-ANSWER INSTRUCTION]: You MUST output ONLY the direct final answer. DO NOT write steps, reasoning, breakdown, analysis, or explanations. For multiple-choice questions, output ONLY the correct option letter and/or answer text (e.g. "Đáp án: 2" or "D. 2"). Keep the response under 1-2 lines.`;
    }

    const finalSystemPrompt = `${systemPrompt || ''}${directSysInstruction}\n\n[STRICT LANGUAGE REQUIREMENT]: You MUST provide your entire solution, explanations, step-by-step reasoning, and answer in ${targetLangName}. Do NOT use any other language unless explicitly requested.`.trim();

    const nanoPromptBase = nanoSystemPrompt || DEFAULT_NANO_SYSTEM_PROMPT;
    const nanoFinalSystemPrompt = `${nanoPromptBase}${directSysInstruction}\n\n[STRICT LANGUAGE]: You MUST reply in ${targetLangName}.`.trim();

    // 1. nano_only Strategy: 100% On-Device execution
    if (routingStrategy === 'nano_only') {
      onChunk('', { status: 'connecting', model: 'Gemini Nano (On-Device)', provider: 'chrome-builtin' });
      await this.streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt: nanoFinalSystemPrompt }, onChunk, signal);
      return;
    }

    // 2. prefer_nano Strategy (When text-only and no preferred external config, run Gemini Nano directly)
    if (routingStrategy === 'prefer_nano' && !imageBase64 && !preferredConfigId) {
      try {
        onChunk('', { status: 'connecting', model: 'Gemini Nano (On-Device)', provider: 'chrome-builtin' });
        await this.streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt: nanoFinalSystemPrompt }, onChunk, signal);
        return;
      } catch (nanoErr) {
        if (enabledKeys.length === 0) throw nanoErr;
        onChunk('', {
          status: 'switching',
          notice: 'Gemini Nano không khả dụng, tự động chuyển sang mô hình Cloud Vision API...',
          error: nanoErr.message,
        });
      }
    }

    // 3. API Config Pool Execution (used for prefer_config, config_only, or prefer_nano fallback/multimodal)
    let attempts = 0;
    const maxAttempts = 3;

    while (attempts < maxAttempts) {
      attempts++;
      const { config, strategy, totalAvailable } = await keyRotator.getHealthyConfigs(preferredConfigId);

      if (!config) {
        // Fallback to Gemini Nano if prefer_config is set
        if (routingStrategy === 'prefer_config' || routingStrategy === 'prefer_nano') {
          onChunk('', {
            status: 'switching',
            notice: 'Không có API Key khả dụng, tự động chuyển về Gemini Nano On-Device...',
          });
          await this.streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt: nanoFinalSystemPrompt }, onChunk, signal);
          return;
        }
        throw new Error('Chưa có API Key nào được kích hoạt trong Cài đặt.');
      }

      try {
        onChunk('', { status: 'connecting', model: config.model, provider: config.provider, attempt: attempts });

        if (config.provider === 'chrome-builtin') {
          await this.streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt: nanoFinalSystemPrompt }, onChunk, signal);
        } else {
          // Gemini / Claude / OpenAI-compatible (OpenAI, DeepSeek, Groq, OpenRouter, Custom).
          // The actual fetch() runs in the offscreen document, not here — MV3 kills the
          // service worker if a fetch() response takes over 30s to arrive, and "thinking"
          // models routinely take longer than that just to send their first byte.
          await streamViaOffscreen(config.provider, config, { prompt, imageBase64, studyMode, outputLanguage, systemPrompt: finalSystemPrompt }, onChunk, signal);
        }

        // Successfully completed
        await keyRotator.reportSuccess(config.id);
        return;
      } catch (err) {
        if (signal?.aborted) {
          throw err;
        }

        console.warn(`[AiEngine] Attempt ${attempts} failed on model ${config.model}:`, err);
        const statusCode = err.status || 500;
        await keyRotator.reportFailure(config.id, statusCode);

        if (attempts >= maxAttempts || totalAvailable <= 1) {
          // Last resort fallback to Gemini Nano if prefer_config
          if (routingStrategy === 'prefer_config' || routingStrategy === 'prefer_nano') {
            onChunk('', {
              status: 'switching',
              notice: 'Tất cả API Key đều bận hoặc không kết nối được, tự động chuyển về Gemini Nano On-Device...',
            });
            await this.streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt: finalSystemPrompt }, onChunk, signal);
            return;
          }
          throw err;
        }

        // Notify UI about failover
        onChunk('', {
          status: 'switching',
          notice: `Key ${config.model} gặp giới hạn, tự động xoay sang key dự phòng...`,
          error: err.message,
        });
      }
    }
  }

  /**
   * Chrome Built-in AI (Gemini Nano On-Device Prompt API)
   */
  static async streamChromeBuiltin({ prompt, imageBase64, studyMode, outputLanguage, systemPrompt }, onChunk, signal) {
    if (imageBase64) {
      onChunk('', {
        status: 'switching',
        model: 'gemini-nano',
        isBuiltin: true,
        notice: 'Chrome Gemini Nano On-Device hiện tại chuyên về xử lý văn bản. Để phân tích hình ảnh và đồ thị, bạn có thể thêm API Key Google Gemini (Miễn phí) trong Cài đặt.',
      });
    }

    const fullPrompt = formatStudyPrompt(studyMode, prompt, outputLanguage);
    const getAi = () => {
      if (typeof chrome !== 'undefined' && chrome.aiOriginTrial?.languageModel) {
        return chrome.aiOriginTrial.languageModel;
      }
      if (typeof ai !== 'undefined' && ai?.languageModel) {
        return ai.languageModel;
      }
      const g = typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : {});
      return g.ai?.languageModel || g.ai?.assistant || g.LanguageModel || null;
    };
    const aiModel = getAi();

    if (aiModel && typeof aiModel.create === 'function') {
      const session = await aiModel.create({
        systemPrompt: systemPrompt || undefined,
        temperature: 0.4,
        topK: 3,
      });

      if (typeof session.promptStreaming === 'function') {
        const stream = session.promptStreaming(fullPrompt, { signal });
        let accumulated = '';
        for await (const chunk of stream) {
          let delta = '';
          if (typeof chunk === 'string') {
            if (chunk.startsWith(accumulated)) {
              delta = chunk.slice(accumulated.length);
              accumulated = chunk;
            } else {
              delta = chunk;
              accumulated += chunk;
            }
          }
          if (delta) {
            onChunk(delta, { status: 'streaming', model: 'Gemini Nano (On-Device)', isBuiltin: true });
          }
        }
        chrome.storage?.local?.set?.({ isNanoReady: true });
        return;
      } else {
        const reply = await session.prompt(fullPrompt);
        onChunk(reply, { status: 'streaming', model: 'Gemini Nano (On-Device)', isBuiltin: true });
        chrome.storage?.local?.set?.({ isNanoReady: true });
        return;
      }
    }

    // Fallback: Run via active web tab where window.ai is directly exposed by Chrome
    let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    let targetTab = tabs && tabs[0]?.url && tabs[0].url.startsWith('http') ? tabs[0] : null;

    if (!targetTab) {
      const allWebTabs = await chrome.tabs.query({ url: ['https://*/*', 'http://*/*'] });
      targetTab = allWebTabs && allWebTabs.length > 0 ? allWebTabs[0] : null;
    }

    if (!targetTab?.id) {
      throw new Error(
        'Chrome Built-in AI cần ít nhất 1 tab web thông thường (https://) đang mở để kết nối. Bạn hãy mở một tab web (như https://google.com) rồi thử lại nhé.'
      );
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      world: 'MAIN',
      func: async (promptText, sysPrompt) => {
        const g = typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : {});
        const m = g.ai?.languageModel || g.ai?.assistant || (typeof ai !== 'undefined' ? (ai.languageModel || ai.assistant) : null);
        if (!m) throw new Error('Trình duyệt chưa sẵn sàng window.ai trên tab web.');
        const session = await m.create({ systemPrompt: sysPrompt || undefined });
        return await session.prompt(promptText);
      },
      args: [fullPrompt, systemPrompt || ''],
    });

    const reply = results?.[0]?.result;
    if (reply) {
      onChunk(reply, { status: 'streaming', model: 'Gemini Nano (On-Device)', isBuiltin: true });
      chrome.storage?.local?.set?.({ isNanoReady: true });
    } else {
      throw new Error('Không nhận được phản hồi từ Gemini Nano.');
    }
  }
}

